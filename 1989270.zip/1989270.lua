-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Slay the Princess — The Pristine Cut
-- App ID: 1989270

addappid(3845330)  -- The Art of Slay the Princess - Digital Art Book (DLC)

addappid(1989270)  -- Slay the Princess — The Pristine Cut

addappid(1989271, 1, "d28b035c178523e9824d85af2171fc42463e9e7b1c4e1845de83bc0e1e0d9a53")  -- Depot 1989271
setManifestid(1989271, "6226378726358942197")

setManifestid(1989272, "2491764113538269831")

addappid(2642210)  -- Slay the Princess - Supporters Pack (DLC)
addappid(1989273, 1, "17fc5b4ca7f5602fd795e28f59f2b1378f0733bbb7c75142d5cf72becee0b3d7")  -- Depot 1989273
setManifestid(1989273, "3295542048348174230")

setManifestid(3845330, "8701606167351034331")

-- ═══════════════════════════════════════════════════════
-- Generated: Sun, 12 Apr 2026 14:20:57 GMT
-- Depots: 2 | Manifests: 4 | All included ✓
-- DLCs: 2
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════