-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Megabonk
-- App ID: 3405340

addappid(3405340)  -- Megabonk
addappid(3405341,0,"d9a92d0ab707134e1d6d8a7f6f5c3e1211d295e888e3cf780efbf560d4e15c4e")  -- Depot 3405341
setManifestid(3405341,"6464790072963772385")
addappid(3405342,0,"0fbab2971279bba685debbfa503e2da7e014fb5066cec822fcda80f9465e304e")  -- Depot 3405342
setManifestid(3405342,"446680890915713051")
-- ═══════════════════════════════════════════════════════
-- Generated: Tue, 07 Apr 2026 13:49:28 GMT
-- Depots: 2 | Manifests: 2 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════