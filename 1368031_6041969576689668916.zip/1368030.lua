-- 1368030's Lua and Manifest Created by Morrenus
-- ANNO:Mutationem
-- Created: February 05, 2026 at 16:23:38 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1368030, 1, "8e5ee1a4d2f48cc19a81efe114633f8aec9be2bc1cb22e7bd07ff004f90ccc89") -- ANNO:Mutationem
addtoken(1368030, "6936581589546791641")
-- MAIN APP DEPOTS
addappid(1368031, 1, "3332efc299cec15a93d1602555631c48f6272e69159b6cdd85a42aae0c5c5c22") -- Depot 1368031
setManifestid(1368031, "6041969576689668916", 9909870805)
addappid(1368032, 1, "582490ac3dde535d869ad831ea6c527ee8d2945f1cc7e903241e938bb750abac") -- Depot 1368032
setManifestid(1368032, "3547234057574725484", 9883862441)
-- DLCS WITH DEDICATED DEPOTS
-- ANNO Mutationem - Collectors Upgrade Pack (AppID: 1909960)
addappid(1909960)
addtoken(1909960, "3026245640165213879")
addappid(1909960, 1, "07a45b03b0c6f5bf92fb6f84ed9877e0908f29f89663a644d6cb3438188281d8") -- ANNO Mutationem - Collectors Upgrade Pack - Depot 1909960
setManifestid(1909960, "8722771999527886706", 4298390)