-- 2914150's Lua and Manifest Created by Hubcap Manifest
-- Yunyun Syndrome!? Rhythm Psychosis
-- Created: April 24, 2026 at 00:41:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 6 (1 excluded)

-- MAIN APPLICATION
addappid(2914150) -- Yunyun Syndrome!? Rhythm Psychosis
-- MAIN APP DEPOTS
addappid(2914151, 1, "b1591193815ae73a16edda181a76e82de4c309d8390cd9845dc4d3234828cd4f") -- Depot 2914151
setManifestid(2914151, "3119298146931325780", 2816528229)
addappid(2914152, 1, "895ab86b71bd36d16aa55f77398958dfd8d65887bb77a013ebb5510e959683db") -- Depot 2914152
setManifestid(2914152, "1760257574849926377", 2669)
-- DLCS WITH DEDICATED DEPOTS
-- Yunyun Syndrome Rhythm Psychosis - DIGITAL ARTWORKS (AppID: 4535570)
addappid(4535570)
addappid(4535570, 1, "42c1266aeecdd79fa0701b6661f0dbb4271cc21cf24bdbcd8dce2a0308edacc7") -- Yunyun Syndrome Rhythm Psychosis - DIGITAL ARTWORKS - Depot 4535570
setManifestid(4535570, "7019849430230487716", 172896155)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4535490) -- Yunyun Syndrome Rhythm Psychosis - Extra Song Pack feat. Touhou
addappid(4535510) -- Yunyun Syndrome Rhythm Psychosis - Extra Pack feat. HARDCORE TANOC BGM
addappid(4535520) -- Yunyun Syndrome Rhythm Psychosis - Extra Song Pack feat. Nanahira
addappid(4535530) -- Yunyun Syndrome Rhythm Psychosis - Extra Song Pack feat. Rish
addappid(4535540) -- Yunyun Syndrome Rhythm Psychosis - Extra Song Pack feat. FrontWing
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4593360) -- DLC 4593360 (unreleased)