-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(264710)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(264711)
addappid(264712,0,"d764b2a41e9bdbf338f04948309614ea6f8d462073a610940aaf10cbfc35aa85")
setManifestid(264712,"3638894940716012854")
addappid(264713,0,"6da396b527d2b570a039778566cef5c1e94ba486fefa835553a1831e40353dec")
setManifestid(264713,"6406809907156750445")