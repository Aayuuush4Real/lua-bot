-- Generated with Luie @ https://lua.tools/
-- 3010850 - Gears of War: E-Day
-- Generated 2026-10-08 01:56:18 UTC
-- # Depots (Total/DLC/Shared): 26/0/3

-- Main AppID
addappid(3010850, 1, "f05d8ccc4c0840cb8b71e6e8cf2f958b1d6e51834d729e5d0bc60e0ca4e7cc73")

-- Main Depots
addappid(3010851, 1, "65989b880d683f38c64d6757a5d1d3d59032ecf11ed695e993a7bf85b3c5a8b3")
-- setManifestid(3010851, "589946541028810466", 115950866691)
addappid(3010852, 1, "8c99068e14cf054c7c983711f73ca73fcefd995b0add04d25face3431b782599") -- English (windows, 64-bit)
-- setManifestid(3010852, "1623146891674219196", 1127452655)
addappid(3010853, 1, "c546deaa1b2237658133e1f6b4ea3d2b85ccd8a445c4b80576f5cb49a4506b2c") -- French (windows, 64-bit)
-- setManifestid(3010853, "5641666117441103276", 1056180098)
addappid(3010854, 1, "40e99b4bd1cac847ef303c0fe59438fed994d022889a47691596c0504922be47") -- Italian (windows, 64-bit)
-- setManifestid(3010854, "7842288679537472608", 1080242676)
addappid(3010855, 1, "e1ddf3c4521dcc4809b2e0c31fc2efedbf97d25b0b06a3caa0db16bd08b9feb6") -- German (windows, 64-bit)
-- setManifestid(3010855, "4741764988348879715", 1095750346)
addappid(3010856, 1, "33bfa0093bb01404c788fd9f9dd8bb9907905db9420ce31aeeefa4e9023419c2") -- Spanish (windows, 64-bit)
-- setManifestid(3010856, "7500983488891394520", 1163885458)
addappid(3010857, 1, "33fe033069218aa8799e40a3134baad6beaa40eecbcba2e203d6f80765c0192c") -- Latam (windows, 64-bit)
-- setManifestid(3010857, "5661683038587223445", 1075731609)
addappid(3010858, 1, "15a291a458b3a8cc24bbb0a431a45b44b3451a003bb666ca3d063bfb71449879") -- Schinese (windows, 64-bit)
-- setManifestid(3010858, "2839267668550678026", 1064878645)
addappid(3010859, 1, "9349e2f972729e315775e1b51c33a7d42b5ee1e7f9134928f82679dfa50a8bc2") -- Tchinese (windows, 64-bit)
-- setManifestid(3010859, "3161761387560006332", 985952651)
addappid(4632451, 1, "837f6a1813cd772451dd35020762bc9554de7f9f017c37093160da6acd45fc8f") -- Brazilian (windows, 64-bit)
-- setManifestid(4632451, "2022406413323326568", 1039800191)
addappid(4632452, 1, "b0bb562abc528cb7ec2433bf4e4a151097acc7da8be235c9e66ec8208ce0e2e2") -- Arabic (windows, 32-bit)
-- setManifestid(4632452, "584420169081214087", 1127452655)
addappid(4632453, 1, "1ad5435036d7822c8e80f4de30a33e6fc70f6b7100257a8129c878c410768831") -- Czech (windows, 64-bit)
-- setManifestid(4632453, "110781742900707025", 1127452655)
addappid(4632454, 1, "e2ac056694c9818dcdf92693d9d5cde90eb0568b6fcd378b9da4be1181eeb0c4") -- Dutch (windows, 64-bit)
-- setManifestid(4632454, "7593712438486890954", 1127452655)
addappid(4632455, 1, "b3229ee65a8533b30884b216a4737e30668f4ff9f827cc331b487e4892a646c5") -- Finnish (windows, 64-bit)
-- setManifestid(4632455, "8855534391050325947", 1127452655)
addappid(4632456, 1, "069978c99940b33439fa645e112cd37ab4b659181793efb6a4cf48e8ac3d6f88") -- Hungarian (windows, 64-bit)
-- setManifestid(4632456, "4102480298744588383", 1127452655)
addappid(4632457, 1, "0d33bee5a7b55d5f1bb17b37e920076a3def0ab87be0cc4dae6a6ed5dacb9e70") -- (windows, 64-bit)
-- setManifestid(4632457, "1511590947950844554", 1127452655)
addappid(4632458, 1, "996ae669f1b564214346987a03c329eac3a7d192028e44d123f993659e5109c8") -- Polish (windows, 64-bit)
-- setManifestid(4632458, "4228571548601960445", 1127452655)
addappid(4632459, 1, "db379c9db7ec0e3edfc09d2b40e720a903bf0654516b697075350afba241a484") -- Russian (windows, 64-bit)
-- setManifestid(4632459, "8350025623011601355", 1127452655)
addappid(4637141, 1, "86c30072fae9663899486a79230acee96ba45bac3820d4057102cddd47138932") -- Swedish (windows, 64-bit)
-- setManifestid(4637141, "3883002926053736657", 1127452655)
addappid(4637142, 1, "65ff13ead16eda6c5eba2517a78d6434b47bcef5d37cd47926bf99784c00753b") -- Turkish (windows, 64-bit)
-- setManifestid(4637142, "8891246442924795040", 1127452655)
addappid(4637143, 1, "0e078c395518752e4aec63fd03a2447041058271e8a27e13bf2c5ee62b83626c") -- Portuguese (windows, 64-bit)
-- setManifestid(4637143, "6104172991436588446", 1127452655)
addappid(4637144, 1, "906891d28c7c771687903a045c2d9b559e406d0c90dec558e51cfb07d81ec300") -- Japanese (windows, 64-bit)
-- setManifestid(4637144, "8177493563246915765", 1007388261)
addappid(4637145, 1, "4da31b54a8e22bf9650ac2b534467a9d6fdefc59e4d9c41cd00de866d82cd970") -- Koreana (windows, 64-bit)
-- setManifestid(4637145, "7558515880004545057", 1065754462)

-- DLC's (no depot keys required)
addappid(4632450) -- E-Day Premium DLC
addappid(4637140) -- E-Day Season 1
addappid(4637200) -- E-Day Pre-Order DLC
addappid(4637220) -- Luke Preece "Marcus" Weapon Skin Set
addappid(5027470) -- E-Day Premium Edition Upgrade
addappid(5028540) -- E-Day Liquid Death Bundle
addappid(5028550) -- E-Day Prince Street Pizza
addappid(5028560) -- E-Day Premium 1000 Iron

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
