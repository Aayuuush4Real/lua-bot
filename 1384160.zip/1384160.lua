-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: GUILTY GEAR -STRIVE-
-- App ID: 1384160

addappid(3001250)  -- GGST Additional Character 18 - Jam Kuradoberi (DLC)
addappid(4413190)  -- Guilty Gear -Strive- Season Pass 5 (DLC)
addappid(3001240)  -- GGST Additional Character 17 - Lucy (DLC)
addappid(3001230)  -- GGST Additional Character 16 - Unika (DLC)
addappid(3001260)  -- GGST Additional Battle Stage 7 - In the Name of Peace (DLC)
addappid(3001270)  -- GGST Additional Battle Stage 8 - New Dawn, A Future Unfolding (DLC)
addappid(2524080)  -- GGST Additional Character 15 - Venom (DLC)
addappid(2524070)  -- GGST Additional Character 14 - Queen Dizzy (DLC)
addappid(2524120)  -- GGST Season 4 Characters Additional Colors (DLC)
addappid(3060720)  -- Guilty Gear -Strive- Season Pass 4 (DLC)
addappid(2524060)  -- GGST Additional Character 13 - Slayer (DLC)
addappid(2524100)  -- GGST Additional Battle Stage 6 - Amber Fest with Kind Neighbors (DLC)
addappid(2524050)  -- GGST Additional Character 12 - A.B.A (DLC)
addappid(2524090)  -- GGST Additional Battle Stage 5 - Fallen Prayer, Engulfed Lives (DLC)
addappid(1652892)  -- Guilty Gear -Strive- Season Pass 3 (DLC)
addappid(2524040)  -- GGST Additional Character 11 - Elphelt Valentine (DLC)
addappid(2524030)  -- GGST Additional Character 10 - Johnny (DLC)
addappid(2524110)  -- GGST Season 3 Characters Additional Colors (DLC)
addappid(2410760)  -- GGST Guilty Gear 25th Anniversary Appreciation Color (DLC)
addappid(2410761)  -- Guilty Gear 25th Anniversary Colors (DLC)
addappid(1649880)  -- Guilty Gear -Strive- Season Pass 1 (DLC)
addappid(1652890)  -- Guilty Gear -Strive- Season Pass 2 (DLC)
addappid(2081054)  -- Guilty Gear -Strive- Additional Colors #2 DLC (DLC)
addappid(1544406)  -- Guilty Gear -Strive- Additional Colors #1 DLC (DLC)
addappid(1544401)  -- GGST Additional Character 1 - Goldlewis Dickinson (DLC)
addappid(1544402)  -- GGST Additional Character 2 - Jack-O (DLC)
addappid(1544403)  -- GGST Additional Character 3 - Happy Chaos (DLC)
addappid(1544404)  -- GGST Additional Character 4 - Baiken (DLC)
addappid(1544405)  -- GGST Additional Character 5 - Testament (DLC)
addappid(2081050)  -- GGST Additional Character 6 - Bridget (DLC)
addappid(2081051)  -- GGST Additional Character 7 - Sin Kiske (DLC)
addappid(2081052)  -- GGST Additional Character 8 - Bedman? (DLC)
addappid(2081053)  -- GGST Additional Character 9 - Asuka (DLC)
addappid(1544407)  -- GGST Additional Battle Stage 1 - Lap of the Kami (DLC)
addappid(1544408)  -- GGST Additional Battle Stage 2 - White House Reborn (DLC)
addappid(2081055)  -- GGST Additional Battle Stage 3 - Fairy's Forest Factory (DLC)
addappid(2081056)  -- GGST Additional Battle Stage 4 - Tír na nÓg (DLC)

addappid(1384160)  -- GUILTY GEAR -STRIVE-

addappid(1384161, 1, "6a00a68034e78cffd8a0e7bb055e336446bf6b732c3605b5c96b73cffa5b3ecd")  -- Depot 1384161
setManifestid(1384161, "8775076599532974952")

addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")  -- Depot 228989
setManifestid(228989, "3514306556860204959")

addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")  -- Depot 228990
setManifestid(228990, "1829726630299308803")

-- ═══════════════════════════════════════════════════════
-- Generated: Thu, 16 Apr 2026 10:34:25 GMT
-- Depots: 3 | Manifests: 3 | All included ✓
-- DLCs: 37
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════