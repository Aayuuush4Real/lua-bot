-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1608290)
addappid(1608291,0,"e46bfbf4201bb8d293e80d779cce6a9dfefbdb8feadaf40f8d283ac16990726e")
setManifestid(1608291,"4465776011688534955")