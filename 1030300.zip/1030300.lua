-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1030300)
addappid(1030301,0,"f4a253f96969f93b8a9392cddf6f1b779886ea10a160e7ca148b92bae09abd28")
setManifestid(1030301,"3545882420322545098")