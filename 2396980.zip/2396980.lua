-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2396980)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(2396981,0,"62bc96ae2b5b2f680456b0ec8a425ab43d8a57725810e3c3efe590cf7e31f6fc")
setManifestid(2396981,"7446262883229267890")