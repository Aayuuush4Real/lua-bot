-- Fetched from DeathStruck API
-- Owner: death_342
-- Game: Liar's Bar
-- App ID: 3097560

addappid(3097560)  -- Liar's Bar
addappid(3097561,0,"86eb48bd45b0ad6b6c525996f1844bb03ddd150dff04f65f5119418b10017dd3")  -- Depot 3097561
setManifestid(3097561,"4973165768027347133")
-- ═══════════════════════════════════════════════════════
-- Generated: Wed, 08 Apr 2026 06:39:52 GMT
-- Depots: 1 | Manifests: 1 | All included ✓
-- DLCs: 0
-- DeathStruck API • deathstruckapi.lol
-- ═══════════════════════════════════════════════════════