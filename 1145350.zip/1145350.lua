-- 1145350's Lua and Manifest Created by Morrenus
-- Hades II
-- Created: November 13, 2025 at 06:08:58 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1145350) -- Hades II
-- MAIN APP DEPOTS
addappid(1145352, 1, "ff02298666a5470ddca19f89593983136f6d1727fc82957ca6b847133783b4e7") -- Depot 1145352
setManifestid(1145352, "7530554120167153777", 10729464450)
addappid(1145354, 1, "71f0364cb7bd2b7d7755605c7983bf2b73101a6e2e0ef6b7082d275a4650f7e5") -- Depot 1145354
setManifestid(1145354, "5044838046341572335", 186560216)
addappid(1145355, 1, "67def0278f458945e71a75914c686e5bf4d3f90c8b4320795c3b78ad999afc56") -- Depot 1145355
setManifestid(1145355, "6267664061058644597", 10874168965)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)