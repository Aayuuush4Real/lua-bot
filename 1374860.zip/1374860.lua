-- 1374860's Lua and Manifest Created by Hubcap Manifest
-- Nocturne
-- Created: October 08, 2026 at 20:48:01 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 25808143 (public branch)
-- Build Date: October 08, 2026 at 11:48:13 EDT (1791474493)
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1374860, 1, "6e91f4838bcf62e4841c83f0f2e833ab8d1eb712541e897f596f08476adde317") -- Nocturne
-- MAIN APP DEPOTS
addappid(1374861, 1, "80bce93ff63293cf7c65f43a8a0fb091fb0d2e483dd2d4e0745a18be0d968edd") -- Depot 1374861
setManifestid(1374861, "3898600985879800559", 14705707437)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(5170560) -- Nocturne - Supporter Pack